int funcao(){
    int a =100
    a = a+23
    return a;
}

int main(){
    funcao();
}
