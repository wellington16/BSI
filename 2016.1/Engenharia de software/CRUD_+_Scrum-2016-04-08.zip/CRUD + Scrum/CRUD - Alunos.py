alunos= {}
print "Cadastro de alunos\n###################"
while True:    
    print "\nEscolha uma opcao:"
    print "1- Cadastrar"
    print "2- Alterar"
    print "3- Listar"
    print "4- Buscar"
    print "5- Remover"
    print "6- Sair"
    
    opcao = input("\n ")
    if opcao == 6:
        break
    elif opcao == 1:        
        nome = raw_input("\nNome: ")
        curso = raw_input("Curso: ")
        telefone = raw_input("Telefone: ")
        cpf = raw_input("CPF: ")
        alunos[nome] = {"curso":curso, "telefone":telefone, "cpf":cpf}
        print "Dados salvos"
        
    elif opcao == 2:
        while True:
                print "\nEscolha uma opcao:"
                print "1-Atualizar Nome"
                print "2-Atualizar Curso"
                print "3-Atualizar Telefone"
                print "4-Atualizar CPF"
                print "0-Voltar"
                opcao = input(": ")
                if opcao == 0:
                    break
                elif opcao == 1:
                    nome = raw_input("Digite o antigo nome do aluno: ")                
                    if alunos.has_key(nome): 
                        novoNome = raw_input("Digite o novo nome do aluno: ")
                        alunos[novoNome] = alunos.pop(nome)
                    else:
                        print "Nome de aluno invalido"
                elif opcao == 2:
                    nome = raw_input("Digite o nome do aluno: ")                
                    if alunos.has_key(nome):
                        curso = raw_input("Digite o novo curso: ")
                        alunos[nome]['curso'] = curso
                    else:
                        print "Nome de aluno invalido"
                elif opcao == 3:
                    nome = raw_input("Digite o nome do aluno: ")                
                    if alunos.has_key(nome):
                        nTelefone = raw_input("Digite o novo telefone do aluno: ")
                        alunos[nome]['telefone'] = nTelefone
                    else:
                        print "Nome de aluno invalido"
                elif opcao == 4:
                    nome = raw_input("Digite o nome do aluno: ")                
                    if alunos.has_key(nome):
                        nCPF = raw_input("Digite o novo CPF do aluno: ")
                        alunos[nome]['cpf'] = nCPF
                    else:
                        print "Nome de aluno invalido"
    elif opcao == 3:
        for chave, valor in alunos.iteritems():
                print "\nNome:", chave
                print "Curso:", valor["curso"]
                print "Telefone:", valor["telefone"]
                print "CPF:",valor["cpf"]
    
    elif opcao == 4:
        nome = raw_input("Digite o nome do aluno: ")                
        if alunos.has_key(nome):
            for chave, valor in alunos.iteritems():
                if nome == chave:
                    print "\nNome:", chave
                    print "Curso:", valor["curso"]
                    print "Telefone:", valor["telefone"]
                    print "CPF:",valor["cpf"]
        else:
            print "Aluno ainda nao encontrado"
                
    elif opcao == 5:
        nome = raw_input("Digite o nome do aluno: ")                
        if alunos.has_key(nome): 
            alunos.pop(nome)
            print "Aluno deletado com sucesso"
        else:
            print "Nome de aluno invalido"
    else:
        print "\nOpcao invalida!\n"

