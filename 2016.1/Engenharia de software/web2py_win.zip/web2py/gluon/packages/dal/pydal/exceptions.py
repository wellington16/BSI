# -*- coding: utf-8 -*-


class NotFoundException(Exception):
    pass


class NotAuthorizedException(Exception):
    pass
