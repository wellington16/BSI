<html>
<head>
<title>:: home:: </title>

</head>
<body>
<blockquote>
<p>
+ view customer +<br/>
<a href =" add_customer.php">+ add new customer +</a><br/>
</p>
</blockquote>
</body>
</html>
