
<head>
<title> ::add customer::</title>
</head>
<body>
<form action='insert_customer.php' method='POST'>
<blockquote>
<p>
<h2>+ add new customer +</h2><br><br/>
Primeiro nome: <input type='text' name='primero_nome'/><br><br/>
Ultimo nome:  <input type='text' name='ultimo_nome'/><br><br/>
Idade: <input type='text' name='idade'/><br><br/>
Email: <input type='text' name='email'/><br><br/>
<input type='submit' name ='submit' value='savar'/>
<input type='reset' name ='reset' value='reset'/>
<input type='button' name ='cancel' value='cancel' onclick= 'location.href="index.php"'/>
</p>
</blockquote>
</body>
</html> 