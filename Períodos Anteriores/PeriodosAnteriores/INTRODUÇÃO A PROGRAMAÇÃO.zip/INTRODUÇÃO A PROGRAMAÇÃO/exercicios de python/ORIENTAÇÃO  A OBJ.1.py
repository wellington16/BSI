'''class Exemplo:
    def _init_(self,a=2,b=3):
        self.a=a
        self.b=b
        def f(self,x):
            return self.a*x+self.b'''
class retangulo:
    lado_a=None
    lado_b=None
    def _init_(self,lado_a,lado_b):
        self.lado_a=lado_a
        self.lado_b-lado_b
        print ("criada uma instancia retangulo")
def calcula_area(self):
    return self.lado_a*self.lado_b
def calcula_perimentro(self):
    return 2* self.lado_a+2*self.lado_b
