# coding=UTF-8
largura = input("Digite a largura: ")
altura = input("Digite a altura: ")
area = largura*altura
print("Média = %.2f" % (area))