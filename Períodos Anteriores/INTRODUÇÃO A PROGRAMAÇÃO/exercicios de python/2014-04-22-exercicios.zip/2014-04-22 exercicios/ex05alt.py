# coding=UTF-8
salario = float(input("Digite o salário base em R$: "))
aumento = float(input("Digite o aumento em %: "))
porcentagem = 1+(aumento/100)
salariofinal = salario*porcentagem
print("Salário Final = R$%.2f" % (salariofinal))