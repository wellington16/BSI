# coding=UTF-8
celsius = float(input("Digite a temperatura em Celsius (C): "))
fahrenheit = ((9*celsius)/5) + 32
print("A temperatura em Fahrenheit é %.1fºF" % (fahrenheit))