# coding=UTF-8
nota1 = input("Digite a nota 1: ")
nota2 = input("Digite a nota 2: ")
nota3 = input("Digite a nota 3: ")
media = (nota1+nota2+nota3)/3
print("Média = %.2f" % (media))