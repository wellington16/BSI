# coding=UTF-8
num1 = input("Digite um número real: ")
num2 = input("Digite outro número real: ")
mult = num1*num2
print("%.2f x %.2f = %.2f" % (num1,num2,mult))