# coding=UTF-8
num = input("Digite um valor inteiro: ")
dobro = num*2
print("O dobro de %d é %d" % (num,dobro))