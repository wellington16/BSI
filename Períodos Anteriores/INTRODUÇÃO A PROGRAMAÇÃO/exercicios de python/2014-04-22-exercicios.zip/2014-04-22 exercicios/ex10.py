# coding=UTF-8
dias = input("Digite a quantidade de dias que usou o carro: ")
kms = float(input("Digite a quantidade de km rodados: "))
valor_por_dia = 60
valor_por_km = 0.15
total = (valor_por_dia*dias) + (valor_por_km*kms)
print("Valor total a pagar: R$%.2f" % (total))