# coding=UTF-8
salario = input("Digite o salário base em R$: ")
salariofinal = salario*1.2
print("Salário Final = R$%.2f" % (salariofinal))