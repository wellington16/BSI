# coding=UTF-8
cheque = input("Digite o valor do cheque em R$: ")
cpmf = cheque*0.003
print("O valor a ser pago de CPMF é R$%.2f" % (cpmf))