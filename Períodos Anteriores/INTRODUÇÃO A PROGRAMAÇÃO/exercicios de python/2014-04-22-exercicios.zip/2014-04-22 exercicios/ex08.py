# coding=UTF-8
preco = float(input("Digite o preço em R$: "))
desconto = float(input("Digite o desconto em %: "))
porcentagem = desconto/100
valor = preco*porcentagem
print("Valor do desconto: R$%.2f" % (valor))
precofinal = preco-valor
print("Preço Final: R$%.2f" % (precofinal))