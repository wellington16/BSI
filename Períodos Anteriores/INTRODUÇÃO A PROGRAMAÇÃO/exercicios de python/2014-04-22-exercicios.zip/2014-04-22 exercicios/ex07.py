# coding=UTF-8
alunos = 3
i = 1
while i<=alunos:
	nome = raw_input("Digite o nome: ")
	matricula = raw_input("Digite a matrícula: ")
	i+=1
	print("Nome do Aluno: %s, Matrícula: %s" % (nome,matricula))