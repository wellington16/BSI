# coding=UTF-8
qtde = 5
maior_temp = 0
menor_temp = 50000
soma_temp = 0.0
for i in range(1,(qtde+1),1):
	temp = float(input("Digite a temperatura: "))
	soma_temp+=temp 
	if temp>maior_temp:
		maior_temp = temp
	if temp<menor_temp:
		menor_temp = temp
print("Maior temperatura: %.2f" % maior_temp)
print("Menor temperatura: %.2f" % menor_temp)
media_temp = soma_temp/qtde
print("Média de temperatura: %.2f" % media_temp)