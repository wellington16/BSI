# coding=UTF-8
qtde = 5
candidatoA = 0
candidatoB = 0
candidatoC = 0
nulo = 0
branco = 0 
total_votos = qtde
for i in range(1,(qtde+1),1):
	voto = int(input("Digite o seu voto: "))
	if voto == 1:
		candidatoA+=1
	elif voto == 2:
		candidatoB+=1
	elif voto == 3:
		candidatoC+=1
	elif voto == 4:
		nulo+=1
	elif voto == 5:
		branco+=1
print("Total de votos do candidato A: %d" % candidatoA)
print("Total de votos do candidato B: %d" % candidatoB)
print("Total de votos do candidato C: %d" % candidatoC)
print("Total de votos nulos: %d" % nulo)
print("Total de votos brancos: %d" % branco)
percentual_votos_brancos = (float(branco)/float(total_votos))*100
percentual_votos_nulos = (float(nulo)/float(total_votos))*100
print("Percentual de votos brancos: %.1f%%" % percentual_votos_brancos)
print("Percentual de votos nulos: %.1f%%" % percentual_votos_nulos)