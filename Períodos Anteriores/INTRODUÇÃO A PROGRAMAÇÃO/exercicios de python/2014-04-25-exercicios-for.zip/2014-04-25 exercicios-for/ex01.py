# coding=UTF-8
qtde = 10
for i in range(1,(qtde+1),1):
	itens = input("Quantidade de itens pedidos pelo rep. %d: " % i)
	if itens<0:
		print "Valor inválido"
		continue
	elif itens<20:
		comissao = 10
	elif itens<50:
		comissao = 15
	elif itens<75:
		comissao = 20
	else:
		comissao = 25
	print("Valor de comissão devido: %d%%" % comissao)