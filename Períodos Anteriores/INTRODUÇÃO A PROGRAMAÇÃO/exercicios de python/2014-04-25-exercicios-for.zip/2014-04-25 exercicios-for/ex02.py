# coding=UTF-8
qtde = 3
maior_altura = 0
menor_altura = 50000
media_altura_mulheres = 0
num_homens = 0 
num_mulheres = 0 
sexo_mais_alto = ''
altura_total = 0
altura_mulheres = 0
for i in range(1,(qtde+1),1):
	sexo = raw_input("Digite o sexo (M/F): ")
	altura = float(input("Digite a altura: "))
	altura_total+=altura 
	if altura>maior_altura:
		maior_altura = altura
		sexo_mais_alto = sexo
	if altura<menor_altura:
		menor_altura = altura
	if sexo == 'M':
		num_homens+=1
	if sexo == 'F':
		altura_mulheres+=altura
		num_mulheres+=1
print("A maior altura do grupo é %.2f" % maior_altura)
print("O sexo da pessoa mais alta do grupo é %s" % sexo_mais_alto)
print("A menor altura do grupo é %.2f" % menor_altura)
print("O total de homens é %d" % num_homens)
print("O total de mulheres é %d" % num_mulheres)
media_altura_mulheres = altura_mulheres/num_mulheres
print("A média de altura das mulheres é %.2f" % media_altura_mulheres)