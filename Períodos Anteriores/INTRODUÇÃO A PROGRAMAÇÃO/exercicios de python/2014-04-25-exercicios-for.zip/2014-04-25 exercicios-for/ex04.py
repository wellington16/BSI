# coding=UTF-8
qtde = 10
pares = 0
impares = 0
for i in range(1,(qtde+1),1):
	num = int(input("Digite o seu número inteiro: "))
	if num%2 == 0:
		pares+=1
	else:
		impares+=1
print("Total de números pares: %d" % pares)
print("Total de números ímpares: %d" % impares)