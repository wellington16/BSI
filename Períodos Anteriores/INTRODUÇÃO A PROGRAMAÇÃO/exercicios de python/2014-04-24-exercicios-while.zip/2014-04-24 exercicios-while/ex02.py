# coding=UTF-8
num = input("Digite um número inteiro: ")
if num!= 99:
	if num>0 and num%2==1:
		print num
	while num!=99:
		num = input("Digite um número inteiro: ")
		if num<0 or num%2==0:
			continue
		print num