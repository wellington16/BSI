# coding=UTF-8
base = input("Digite a base: ")
expoente = input("Digite o expoente: ")
valor = 1
while expoente!=0:
	valor*=base
	expoente-=1
print valor