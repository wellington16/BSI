# coding=UTF-8
qtde = 5
i = 0
while i<qtde:
	num = input("Digite um número inteiro: ")
	if num<0:
		print "Erro! Valor negativo!"
		break
	i+=1
else:
	print "Valores inseridos com sucesso"