# coding=UTF-8
anos = input("Digite há quantos anos você fuma: ")
cigarros_dia = float(input("Digite a quantidade média de cigarros que você fuma por dia: "))
perda = 10.0
perda_dia = (cigarros_dia*perda)/(24*60)
perda_total = perda_dia * anos * 365
print("Dias de vida perdidos por conta do cigarro: %.2f" % (perda_total))