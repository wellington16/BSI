# coding=UTF-8
num = input("Digite um número inteiro: ")
fatorial = num
if num <= 20 and num>0:
	while num>1:
		num = num - 1
		fatorial = num*fatorial
	print fatorial
else:
	print "Número fora do intervalo"