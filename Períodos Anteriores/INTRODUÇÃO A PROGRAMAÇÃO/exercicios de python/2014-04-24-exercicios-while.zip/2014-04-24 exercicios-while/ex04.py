# coding=UTF-8
qtde = 0
total = 15
print "2"
num = 3
while qtde>=0:
	i = 2
	primo = True
	while i<num:
		if num%i==0:
			primo = False
			break
		else:
			primo = True
		i+=1
	if primo:
		qtde+= 1
		print num
	if qtde==total:
		break
	num+=1
print "fim do programa"