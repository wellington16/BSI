# coding=UTF-8
resposta = "S"
while resposta == "S":
	num = input("Digite um número inteiro: ")
	i = 1
	while i<10:
		produto = i*num
		print("%d x %d = %d" %(num,i,produto))
		i+=1
	resposta = raw_input("Deseja continuar? (S/N) ")