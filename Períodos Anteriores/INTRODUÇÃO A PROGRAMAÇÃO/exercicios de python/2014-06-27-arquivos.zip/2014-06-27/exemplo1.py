arq = open ("teste.txt", "w")
arq.write ("Oi")
arq.close ()
arq = open ("teste.txt")
x = arq.read()
print x
