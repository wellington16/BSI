arq = open ("test.txt")
x = arq.readlines()
print x
arq.close()
