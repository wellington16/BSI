# coding=UTF-8
s = raw_input("Digite o seu nome: ")
for i in range(len(s)):
	print s[i]

#outra opção abaixo, usando string como lista
for i in s:
	print i