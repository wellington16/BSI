# coding=UTF-8
s = raw_input("Digite uma string: ")
qtde = 0
pos = s.find('ado')
while pos!=-1:
	qtde+=1
	pos = s.find('ado',(pos+1))
print("A quantidade de vezes que a subpalavra 'ado' aparece é %d" % qtde)