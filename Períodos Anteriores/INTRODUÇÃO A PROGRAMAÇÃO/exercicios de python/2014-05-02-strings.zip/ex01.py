# coding=UTF-8
s1 = raw_input("Digite a primeira string: ")
s2 = raw_input("Digite a segunda string: ")

print("String 1: %s" % (s1))
print("String 2: %s" % (s2))

tamanho_s1 = len(s1)
tamanho_s2 = len(s2)

print("Tamanho da String 1: %d" % (tamanho_s1))
print("Tamanho da String 2: %d" % (tamanho_s2))

if tamanho_s1==tamanho_s2:
	tamanho = 'igual'
else:
	tamanho = 'diferente'

if s1==s2:
	conteudo = 'igual'
else:
	conteudo = 'diferente'

print("O tamanho das duas strings é %s" % tamanho)
print("As duas strings possuem conteúdo %s" % conteudo)