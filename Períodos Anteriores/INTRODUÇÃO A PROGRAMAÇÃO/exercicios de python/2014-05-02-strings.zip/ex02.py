# coding=UTF-8
s = raw_input("Digite o seu nome: ")
s = s.upper()
n = ''
for i in range(len(s)-1,-1,-1):
	n+=s[i]
print("O seu nome invertido é %s" % n)