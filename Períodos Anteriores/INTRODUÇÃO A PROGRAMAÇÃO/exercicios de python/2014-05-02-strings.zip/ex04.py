# coding=UTF-8
s = raw_input("Digite o seu nome: ")
for i in range(len(s)):
	print s[0:i+1]

#outra opção de resolver...
escada = ''
for i in s:
	escada+=i
	print escada