#Driver para teste da Classe Lista 
#Algoritmos e Estrutura da Dados
# Prof. Tiago A. E. Ferreira

import sys
from Pilha import Stack

pilha = Stack() #inicialisa uma pilha

print"Processando uma Pilha\n"

for i in range(4):
    stack.puch(i)
    print stack

while not stack.isEmpty():
    pop = stack.pop()
    print pop, "removido da pilha \n"
    print stack
