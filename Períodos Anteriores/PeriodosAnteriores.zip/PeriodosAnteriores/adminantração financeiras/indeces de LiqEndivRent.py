ac=int(input("AC: "))
pc=int(input("PC: "))
rlp=int(input("RLP: "))
elp=int(input("ELP: "))
e = int(input("Estoque: "))
d = int(input("Disponibilidade: "))
pnc = elp

pl = int(input("Patrimonio L.: "))
