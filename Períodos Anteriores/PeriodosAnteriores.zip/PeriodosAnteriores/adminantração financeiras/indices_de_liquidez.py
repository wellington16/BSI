ANO=2014
print(ANO)

AC = 592020
PC = 74136
	
RLP = 464089
ELP = 472594

E = 87653

D = 52278

PNC = ELP
PL = 2908467
PE = PC + PNC

AT = 3455197

ILG = (AC + RLP) / (PC + ELP)
print('ILG =',ILG)

ILC = AC / PC
print( 'ILC =',ILC)

ILS = (AC - E)/PC
print('ILS =', ILS)

ILI = D /PC
print('ILI =', ILI)

CCL = AC - PC
print ('CCL =',CCL)

IEC = PE/PL
print('IEC =',IEC)

ID = PE / AT
print('ID =',ID)

IDCP = PC / AT
print('IDCP =',IDCP)

IC = PC / PE
print('IC =',IC)

#ICJ = 